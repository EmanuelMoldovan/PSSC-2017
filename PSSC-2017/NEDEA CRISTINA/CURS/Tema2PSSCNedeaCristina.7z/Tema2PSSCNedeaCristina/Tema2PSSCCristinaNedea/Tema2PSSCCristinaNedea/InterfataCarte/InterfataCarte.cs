﻿using ColectiiSistemLibrarie;
using Modele.SistemLibrarie.Entitati;
using Modele.SistemLibrarie.ObiecteValori;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace InterfataMedic
{
    public partial class InterfataMedic : Form
    {  
        public InterfataMedic()
        {
            InitializeComponent();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            ServiciiSistemLibrarie.AdaugaClient.adauga_client();
            ServiciiSistemLibrarie.AdaugaCarte.Adauga_Carte();
            Client result = StocareClient.listaClienti.Find(x => x.numeClientt == textBox1.Text);
            Carte resultSecond = StocareCarte.listaCarti.Find(y => y.NumeCartee == textBoxNume.Text && y.NumeAutorr == textBoxPrenume.Text);
            if(resultSecond==null)
            {
                MessageBox.Show("Clientul cautat nu a fost gasit !");
            }
            else
                if (result != null && resultSecond != null)
                {
                    MessageBox.Show( "\nNume client:" + result.numeClientt + "\nPrenume client:"
                        + result.prenumeClientt + "\nOcupatia:" + result.ocupatiaa + "\nNumar inregistrare:" + result.numarInregistraree +
                        "\nData inregistrare:" + result.dataInregistraree);


                }
                else
                    MessageBox.Show("Nu exista o carte cu acest nume.");
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Orar orar = new Orar("08:00-00:00", "10:00-16:00");
            MessageBox.Show("\nOrarul in timpul saptamanii este:" + orar.OrarInTimpulSapt1 +
                "\nOrarul la sfarsitul saptamnii este:" + orar.OrarLaSfSapt1);
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void InterfataMedic_Load(object sender, EventArgs e)
        {

        }
    }
}
