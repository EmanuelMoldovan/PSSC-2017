﻿
using ColectiiSistemLibrarie;
using Modele.SistemLibrarie.Entitati;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace ServiciiSistemLibrarie
{
    public class AdaugaCarte
    {
        public static void Adauga_Carte()
        {
            StocareCarte.listaCarti.Add(new Carte("Poezii", "Mihai Eminescu", "Nemira", 1992));
            StocareCarte.listaCarti.Add(new Carte("Basme", "Petre Ispirescu", "Corint", 2000));
            StocareCarte.listaCarti.Add(new Carte("Anatomia corpului uman", "Carmen Harra", "Universul", 2016));
        }
    }
}
