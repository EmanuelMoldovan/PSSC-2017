﻿using ColectiiSistemLibrarie;
using Modele.SistemLibrarie.Entitati;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using ColectiiBiblioteca;
//using Modele.Biblioteca.Entitati;


namespace ServiciiSistemLibrarie
{
    public class AdaugaLibrarie
    {
        public static void adauga_librarie()
        {
            StocareLibrarie.listaLibrarii.Add(new Librarie("23", "Teilor", "Motru", "Librarie scolara"));
            StocareLibrarie.listaLibrarii.Add(new Librarie("11", "Ion Creanga", "Timisoara", "Librarie universitara"));
           
        }
    }
}
