﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Modele.SistemLibrarie.Entitati;
using ColectiiSistemLibrarie;
using ServiciiSistemLibrarie;


namespace Teste
{
    [TestClass]
    public class TestareIntroducereCarti
    {
        [TestMethod]
        public void TestMethod1Carti()
        {
            //pass
            StocareCarte.listaCarti.Add(new Carte("Povesti", "Ion Creanga", "Creanga de Aur", 1995));
            Assert.IsNull(StocareCarte.listaCarti);
        }

        [TestMethod]
        public void TestMethod2Carti()
        {
            //pass
            AdaugaCarte.Adauga_Carte();
            Assert.IsNotNull(StocareCarte.listaCarti);
        }
    }
}
