﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Modele.SistemLibrarie.Entitati;

namespace ColectiiSistemLibrarie
{
    public class StocareLibrarie
    {
        public static List<Librarie> listaLibrarii = new List<Librarie>();
    }
}
