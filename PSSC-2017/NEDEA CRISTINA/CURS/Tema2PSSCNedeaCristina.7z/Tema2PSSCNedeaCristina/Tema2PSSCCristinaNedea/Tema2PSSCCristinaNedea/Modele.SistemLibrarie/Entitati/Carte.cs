﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modele.SistemLibrarie.Entitati
{
    public class Carte
    {
        private string NumeCarte;
        private string NumeAutor;
        private string Editura;
        private int AnulAparitiei;
        //private int Stoc
        
        public Carte(string numeCarte, string numeAutor, string editura, int anulAparitiei)
        {
            NumeCartee = numeCarte;
            NumeAutorr = numeAutor;
            Edituraa = editura;
            this.AnulAparitieii = anulAparitiei;
        }

        public string NumeCartee { get => NumeCarte; set => NumeCarte = value; }
        public string NumeAutorr { get => NumeAutor; set => NumeAutor = value; }
        public string Edituraa { get => Editura; set => Editura = value; }
        public int AnulAparitieii { get => AnulAparitiei; set => AnulAparitiei = value; }

        public override bool Equals(object obj)
        {
            var carte = obj as Carte;
            return carte != null &&
                   NumeCartee == carte.NumeCartee &&
                   NumeAutorr == carte.NumeAutorr &&
                   Edituraa == carte.Edituraa &&
                   AnulAparitieii == carte.AnulAparitieii;
        }
    }
}
