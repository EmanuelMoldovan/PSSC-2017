﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modele.SistemLibrarie.Entitati
{
    public class Librarie
    {
        private string Numar;
        private string Strada;
        private string Oras;
        private string TipLibrarie;

        public Librarie(string numar, string strada, string oras, string tipLibrarie)
        {
            this.Nr = numar;
            this.Stradaa = strada;
            this.Orass = oras;
            this.TipLibrariee = tipLibrarie;
        }

        public string Nr { get => Numar; set => Numar = value; }
        public string Stradaa { get => Strada; set => Strada = value; }
        public string Orass { get => Oras; set => Oras = value; }
        public string TipLibrariee { get => TipLibrarie; set => TipLibrarie = value; }

        public override bool Equals(object obj)
        {
            var librarie = obj as Librarie;
            return librarie != null &&
                   Nr == librarie.Nr &&
                   Stradaa == librarie.Stradaa &&
                   Orass == librarie.Orass &&
                   TipLibrariee == librarie.TipLibrariee;
        }
    }
}
