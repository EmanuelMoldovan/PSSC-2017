﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modele.SistemLibrarie.Entitati
{
    public class Client
    {
        private string NumeClient;
        private string PrenumeClient;
        private string Ocupatia;
        private string NumarInregistrare;
        private string DataInregistrare;

        public Client(string numeClient, string prenumeClient, string ocupatia, string numarInregistrare, string dataInregistrare)
        {
            numeClientt = numeClient;
            prenumeClientt = prenumeClient;
            ocupatiaa = ocupatia;
            this.numarInregistraree = numarInregistrare;
            this.dataInregistraree = dataInregistrare;
        }

        public string numeClientt { get => NumeClient; set => NumeClient = value; }
        public string prenumeClientt { get => PrenumeClient; set => PrenumeClient = value; }
        public string ocupatiaa { get => Ocupatia; set => Ocupatia = value; }
        public string numarInregistraree { get => NumarInregistrare; set => NumarInregistrare = value; }
        public string dataInregistraree { get => DataInregistrare; set => DataInregistrare = value; }

        public override bool Equals(object obj)
        {
            var client = obj as Client;
            return client != null &&
                   numeClientt == client.numeClientt &&
                   prenumeClientt == client.prenumeClientt &&
                   ocupatiaa == client.ocupatiaa &&
                   numarInregistraree == client.numarInregistraree &&
                   dataInregistraree == client.dataInregistraree;
        }
    }
}
