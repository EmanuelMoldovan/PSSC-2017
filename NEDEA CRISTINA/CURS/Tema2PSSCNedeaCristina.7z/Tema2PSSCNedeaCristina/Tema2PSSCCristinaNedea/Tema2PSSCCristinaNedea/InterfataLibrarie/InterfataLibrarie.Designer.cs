﻿namespace InterfataLibrarie
{
    partial class InterfataLibrarie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBoxEditura = new System.Windows.Forms.TextBox();
            this.textBoxNumeAutor = new System.Windows.Forms.TextBox();
            this.textBoxNumeCarte = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxNumarInregistrare = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBoxDataInregistrare = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxNrInregistrare = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textNumeClient = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.textBoxOcupatia = new System.Windows.Forms.TextBox();
            this.textBoxPrenumeClient = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.textNumInregistrare = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxAnulAparitiei = new System.Windows.Forms.TextBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.numericUpDown1);
            this.groupBox1.Controls.Add(this.textBoxAnulAparitiei);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.textBoxEditura);
            this.groupBox1.Controls.Add(this.textBoxNumeAutor);
            this.groupBox1.Controls.Add(this.textBoxNumeCarte);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox1.Location = new System.Drawing.Point(22, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(343, 207);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Adaugare carte";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 123);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 18);
            this.label6.TabIndex = 9;
            this.label6.Text = "Anul aparitiei";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(138, 163);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(137, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "Adaugare carte";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBoxEditura
            // 
            this.textBoxEditura.Location = new System.Drawing.Point(126, 83);
            this.textBoxEditura.Name = "textBoxEditura";
            this.textBoxEditura.Size = new System.Drawing.Size(211, 25);
            this.textBoxEditura.TabIndex = 5;
            this.textBoxEditura.TextChanged += new System.EventHandler(this.textBoxCNP_TextChanged);
            // 
            // textBoxNumeAutor
            // 
            this.textBoxNumeAutor.Location = new System.Drawing.Point(124, 52);
            this.textBoxNumeAutor.Name = "textBoxNumeAutor";
            this.textBoxNumeAutor.Size = new System.Drawing.Size(213, 25);
            this.textBoxNumeAutor.TabIndex = 4;
            // 
            // textBoxNumeCarte
            // 
            this.textBoxNumeCarte.Location = new System.Drawing.Point(126, 21);
            this.textBoxNumeCarte.Name = "textBoxNumeCarte";
            this.textBoxNumeCarte.Size = new System.Drawing.Size(211, 25);
            this.textBoxNumeCarte.TabIndex = 3;
            this.textBoxNumeCarte.TextChanged += new System.EventHandler(this.textBoxNume_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "Editura";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nume Autor";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nume Carte";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.textBoxNumarInregistrare);
            this.groupBox2.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(32, 252);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(298, 90);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Vizualizare carte sistem";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(148, 47);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(144, 30);
            this.button3.TabIndex = 9;
            this.button3.Text = "Vizualizare carte";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 18);
            this.label4.TabIndex = 9;
            this.label4.Text = "Numar inregistrare";
            // 
            // textBoxNumarInregistrare
            // 
            this.textBoxNumarInregistrare.Location = new System.Drawing.Point(148, 20);
            this.textBoxNumarInregistrare.Name = "textBoxNumarInregistrare";
            this.textBoxNumarInregistrare.Size = new System.Drawing.Size(150, 25);
            this.textBoxNumarInregistrare.TabIndex = 3;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBoxDataInregistrare);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.textBoxNrInregistrare);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.textNumeClient);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.textBoxOcupatia);
            this.groupBox3.Controls.Add(this.textBoxPrenumeClient);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox3.Location = new System.Drawing.Point(390, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(373, 239);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Adaugare client";
            // 
            // textBoxDataInregistrare
            // 
            this.textBoxDataInregistrare.Location = new System.Drawing.Point(136, 138);
            this.textBoxDataInregistrare.Name = "textBoxDataInregistrare";
            this.textBoxDataInregistrare.Size = new System.Drawing.Size(204, 25);
            this.textBoxDataInregistrare.TabIndex = 17;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(7, 145);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(106, 18);
            this.label12.TabIndex = 16;
            this.label12.Text = "Data Inregistrare";
            // 
            // textBoxNrInregistrare
            // 
            this.textBoxNrInregistrare.Location = new System.Drawing.Point(136, 107);
            this.textBoxNrInregistrare.Name = "textBoxNrInregistrare";
            this.textBoxNrInregistrare.Size = new System.Drawing.Size(206, 25);
            this.textBoxNrInregistrare.TabIndex = 14;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 109);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(120, 18);
            this.label11.TabIndex = 12;
            this.label11.Text = "Numar inregistrare:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 18);
            this.label5.TabIndex = 11;
            this.label5.Text = "Nume:";
            // 
            // textNumeClient
            // 
            this.textNumeClient.Location = new System.Drawing.Point(122, 16);
            this.textNumeClient.Name = "textNumeClient";
            this.textNumeClient.Size = new System.Drawing.Size(224, 25);
            this.textNumeClient.TabIndex = 10;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(177, 210);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(137, 23);
            this.button2.TabIndex = 9;
            this.button2.Text = "Adaugare client";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBoxOcupatia
            // 
            this.textBoxOcupatia.Location = new System.Drawing.Point(122, 78);
            this.textBoxOcupatia.Name = "textBoxOcupatia";
            this.textBoxOcupatia.Size = new System.Drawing.Size(224, 25);
            this.textBoxOcupatia.TabIndex = 5;
            // 
            // textBoxPrenumeClient
            // 
            this.textBoxPrenumeClient.Location = new System.Drawing.Point(122, 47);
            this.textBoxPrenumeClient.Name = "textBoxPrenumeClient";
            this.textBoxPrenumeClient.Size = new System.Drawing.Size(224, 25);
            this.textBoxPrenumeClient.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 76);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 18);
            this.label7.TabIndex = 2;
            this.label7.Text = "Ocupatia:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 50);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 18);
            this.label9.TabIndex = 0;
            this.label9.Text = "Prenume:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button4);
            this.groupBox4.Controls.Add(this.textNumInregistrare);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(390, 257);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(346, 91);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Vizualizare clienti sistem";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(164, 54);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(136, 31);
            this.button4.TabIndex = 10;
            this.button4.Text = "Vizualizare client";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // textNumInregistrare
            // 
            this.textNumInregistrare.Location = new System.Drawing.Point(136, 23);
            this.textNumInregistrare.Name = "textNumInregistrare";
            this.textNumInregistrare.Size = new System.Drawing.Size(184, 25);
            this.textNumInregistrare.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 23);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(120, 18);
            this.label10.TabIndex = 2;
            this.label10.Text = "Numar inregistrare:";
            // 
            // textBoxAnulAparitiei
            // 
            this.textBoxAnulAparitiei.Location = new System.Drawing.Point(126, 120);
            this.textBoxAnulAparitiei.Name = "textBoxAnulAparitiei";
            this.textBoxAnulAparitiei.Size = new System.Drawing.Size(211, 25);
            this.textBoxAnulAparitiei.TabIndex = 10;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(134, 128);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 25);
            this.numericUpDown1.TabIndex = 11;
            // 
            // InterfataLibrarie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(775, 360);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "InterfataLibrarie";
            this.Text = "Sistem Librarie";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBoxEditura;
        private System.Windows.Forms.TextBox textBoxNumeAutor;
        private System.Windows.Forms.TextBox textBoxNumeCarte;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxNumarInregistrare;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBoxOcupatia;
        private System.Windows.Forms.TextBox textBoxPrenumeClient;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textNumInregistrare;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textNumeClient;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxDataInregistrare;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxNrInregistrare;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxAnulAparitiei;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
    }
}

