﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Modele.SistemLibrarie.ObiecteValori;
using Modele.SistemLibrarie.Entitati;
using ColectiiSistemLibrarie;
using ServiciiSistemLibrarie;

namespace InterfataLibrarie
{
    public partial class InterfataLibrarie : Form
    {
        public InterfataLibrarie()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            ServiciiSistemLibrarie.AdaugaCarte.Adauga_Carte();
            Carte result = StocareCarte.listaCarti.Find(x => x.Edituraa == textBoxNumarInregistrare.Text);
            if (result != null)
            {
                MessageBox.Show("\nNume Carte:"+result.NumeCartee+"\n:Numele Autorului"+result.NumeAutorr+"\nEditura:"+result.Edituraa
                    +"\nAnul aparitiei:"+result.AnulAparitieii);
            }
            else
                MessageBox.Show("Nu exista carte");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ServiciiSistemLibrarie.AdaugaClient.adauga_client();
            Client result = StocareClient.listaClienti.Find(x => x.numarInregistraree == textNumInregistrare.Text);
            if (result != null)
            {
                MessageBox.Show("\nNumar inregistrare:" + result.numarInregistraree + "\nNume:" + result.numeClientt + "\nPrenume:"
                    + result.prenumeClientt + "\nOcupatia:" + result.ocupatiaa + 
                    "\nData inregistrare:" + result.dataInregistraree);
            }
            else
                MessageBox.Show("Nu exista client cu accest numar de inregistrare");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Client client = new Client(textBoxNumeCarte.Text, textBoxNumeAutor.Text, textBoxOcupatia.Text, textBoxNrInregistrare.Text, textBoxDataInregistrare.Text);
            StocareClient.listaClienti.Add(client);
            MessageBox.Show("Adaugare realizata cu succes!");
        }

        private void button1_Click(object sender, EventArgs e)
        {
           Carte carte = new Carte(textBoxNumeCarte.Text, textBoxNumeAutor.Text, textBoxEditura.Text,
                Convert.ToInt32(numericUpDown1.Value));
            StocareCarte.listaCarti.Add(carte);
            MessageBox.Show("Adaugare realizata cu succes!");
        }

        private void textBoxCNP_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBoxNume_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
