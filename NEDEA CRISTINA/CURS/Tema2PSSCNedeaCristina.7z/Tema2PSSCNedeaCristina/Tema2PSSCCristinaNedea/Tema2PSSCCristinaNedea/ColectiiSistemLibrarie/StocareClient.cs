﻿using Modele.SistemLibrarie.Entitati;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ColectiiSistemLibrarie
{
    public class StocareClient
    {
        public static List<Client> listaClienti = new List<Client>();
    }
}
