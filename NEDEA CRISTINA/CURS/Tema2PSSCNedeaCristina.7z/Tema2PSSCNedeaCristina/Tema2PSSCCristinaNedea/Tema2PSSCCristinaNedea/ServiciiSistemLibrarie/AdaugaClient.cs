﻿using ColectiiSistemLibrarie;
using Modele.SistemLibrarie.Entitati;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ServiciiSistemLibrarie
{
    public class AdaugaClient
    {
        public static void adauga_client()
        {
            StocareClient.listaClienti.Add(new Client("Zaharia", "George", "Student", "4321", "01.11.2016"));
            StocareClient.listaClienti.Add(new Client("Racoceanu", "Ana", "Inginer", "4316", "08.02.2017"));
            StocareClient.listaClienti.Add(new Client("Georgescu", "Andreea", "Elev", "1121", "11.03.2017"));
           
          
        }
    }
}
