﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;






namespace CVBibliotecaTema2PSSC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InterfataCarte.InterfataCarte interfataCarte = new InterfataCarte.InterfataCarte();
            interfataCarte.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            InterfataLibrarie.Interfatalibrarie interfataLibrarie = new InterfataLibrarie.InterfataLibrarie();
            interfataLibrarie.Show();
            

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
