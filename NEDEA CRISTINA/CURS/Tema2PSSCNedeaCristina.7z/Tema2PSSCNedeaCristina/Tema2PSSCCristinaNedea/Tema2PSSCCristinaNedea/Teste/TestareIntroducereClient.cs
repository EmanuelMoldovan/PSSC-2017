﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Modele.SistemLibrarie.Entitati;
using ColectiiSistemLibrarie;
using ServiciiSistemLibrarie;

namespace Teste
{
    [TestClass]
    public class TestareIntroducereClient
    {
        [TestMethod]
        public void TestMethodClient1()
        {
            //fail
            AdaugaClient.adauga_client();
            Assert.IsNull(StocareClient.listaClienti);
        }

        [TestMethod]
        public void TestMethodClient2()
        {
            //pass
            AdaugaClient.adauga_client();
            Assert.IsNotNull(StocareClient.listaClienti);
        }

        
    }
}
