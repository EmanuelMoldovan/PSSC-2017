﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ColectiiSistemLibrarie;
using Modele.SistemLibrarie.Entitati;

namespace Teste
{
    [TestClass]
    public class TestareIntroducereLibrarie
    {
        [TestMethod]
        public void TestMethod1Librarie()
        {
            //pass
            StocareLibrarie.listaLibrarii.Add(new Librarie("11", "Principala", "Timisoara", "Universala"));
            foreach (Librarie angajat in StocareLibrarie.listaLibrarii)
            {
                Assert.AreEqual(angajat.Nr, "11");
                Assert.AreEqual(angajat.Stradaa, "Principala");
                Assert.AreEqual(angajat.Orass, "Timisoara");
                Assert.AreEqual(angajat.TipLibrariee, "Universala");
            }
        }

        [TestMethod]
        public void TestMethod2Librarie()
        {
            //fail
            StocareLibrarie.listaLibrarii.Add(new Librarie("29", "Principala", "Timisoara", "Universala"));
            foreach (Librarie angajat in StocareLibrarie.listaLibrarii)
            {
                Assert.AreEqual(angajat.Nr, "11");
                Assert.AreEqual(angajat.Stradaa, "Principala");
                Assert.AreEqual(angajat.Orass, "Timisoara");
                Assert.AreEqual(angajat.TipLibrariee, "Universala");
            }
        }
    }
}
